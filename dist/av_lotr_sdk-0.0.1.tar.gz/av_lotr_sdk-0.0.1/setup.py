from setuptools import setup

setup(
  name='av_lotr_sdk',
  version='0.0.1',
  author='Aim Verapornpongkul',
  author_email='aimverapornpongkul@gmail.com',
  description='SDK for LOTR API',
  long_description='README.MD',
  url='https://github.com/thisisaim/aim_verapornpongkul-SDK'
)
